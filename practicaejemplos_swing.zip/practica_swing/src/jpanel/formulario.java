package jpanel;

import javax.swing.*;
import java.awt.*;

public class formulario extends JFrame {

    private JTextField txtNombre, txtDNI, txtDia, txtMes, txtAnio;

    public formulario() {
        super("Añadir Usuario");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        //panel de fecha
        JPanel panelFecha = new JPanel(new FlowLayout(FlowLayout.LEFT, 3, 0));
        txtDia  = campoFecha(2, "DD");
        txtMes  = campoFecha(2, "MM");
        txtAnio = campoFecha(4, "AAAA");
        panelFecha.add(txtDia);
        panelFecha.add(new JLabel("/"));
        panelFecha.add(txtMes);
        panelFecha.add(new JLabel("/"));
        panelFecha.add(txtAnio);

        //panel de datos con gridlayout
        JPanel panelDatos = new JPanel(new GridLayout(3, 2, 8, 10));
        panelDatos.setBorder(BorderFactory.createEmptyBorder(15, 15, 10, 15));

        txtNombre = new JTextField(15);
        txtDNI    = new JTextField(15);

        panelDatos.add(labelNegrita("Nombre:"));
        panelDatos.add(txtNombre);
        panelDatos.add(labelNegrita("DNI:"));
        panelDatos.add(txtDNI);
        panelDatos.add(labelNegrita("Fecha de nacimiento:"));
        panelDatos.add(panelFecha);

        //panel de botones
        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));

        JButton btnAceptar = new JButton("Aceptar");
        JButton btnCancelar = new JButton("Cancelar");

        //mejora: validacion al aceptar
        btnAceptar.addActionListener(e -> {
            if (txtNombre.getText().trim().isEmpty() || txtDNI.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(this,
                        "Por favor completá todos los campos.",
                        "Campos incompletos",
                        JOptionPane.WARNING_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this,
                        "Usuario registrado:\n" +
                                "Nombre: " + txtNombre.getText() + "\n" +
                                "DNI: " + txtDNI.getText() + "\n" +
                                "Fecha: " + txtDia.getText() + "/" + txtMes.getText() + "/" + txtAnio.getText(),
                        "Éxito",
                        JOptionPane.INFORMATION_MESSAGE);
            }
        });

        btnCancelar.addActionListener(e -> {
            txtNombre.setText("");
            txtDNI.setText("");
            txtDia.setText(""); txtMes.setText(""); txtAnio.setText("");
        });

        panelBotones.add(btnAceptar);
        panelBotones.add(btnCancelar);

        Container cp = getContentPane();
        cp.add(panelDatos, BorderLayout.CENTER);
        cp.add(panelBotones, BorderLayout.SOUTH);

        pack();
    }

    private JTextField campoFecha(int cols, String tooltip) {
        JTextField tf = new JTextField(cols);
        tf.setToolTipText(tooltip);
        return tf;
    }

    private JLabel labelNegrita(String texto) {
        JLabel l = new JLabel(texto);
        l.setFont(l.getFont().deriveFont(Font.BOLD));
        return l;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new formulario().setVisible(true));
    }
}