package graficos;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class panelDibujo extends JPanel {

    //mejora: la cara del sol sigue al mouse
    private int mouseX = 200, mouseY = 200;

    public panelDibujo() {
        setBackground(new Color(135, 206, 235)); // cielo celeste
        setPreferredSize(new Dimension(450, 450));

        //mejora: el sol se mueve con el mouse
        addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(MouseEvent e) {
                mouseX = e.getX();
                mouseY = e.getY();
                repaint();
            }
        });
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        //mejora: suavizado de bordes
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        int cx = mouseX, cy = mouseY;

        //rayos del sol
        g2.setColor(new Color(255, 200, 0));
        g2.setStroke(new BasicStroke(2));
        for (double d = 0; d < 2 * Math.PI; d += 0.25) {
            int x1 = (int) (cx + 70 * Math.cos(d));
            int y1 = (int) (cy + 70 * Math.sin(d));
            int x2 = (int) (cx + 110 * Math.cos(d));
            int y2 = (int) (cy + 110 * Math.sin(d));
            g2.drawLine(x1, y1, x2, y2);
        }

        //cuerpo del sol
        g2.setColor(new Color(255, 220, 50));
        g2.fillOval(cx - 60, cy - 60, 120, 120);
        g2.setColor(new Color(200, 150, 0));
        g2.setStroke(new BasicStroke(2));
        g2.drawOval(cx - 60, cy - 60, 120, 120);

        //ojos
        g2.setColor(Color.DARK_GRAY);
        g2.fillOval(cx - 25, cy - 20, 14, 14);
        g2.fillOval(cx + 11, cy - 20, 14, 14);

        //sonrisa
        g2.setColor(new Color(180, 80, 0));
        g2.setStroke(new BasicStroke(3));
        g2.drawArc(cx - 22, cy + 5, 44, 25, 200, 140);

        //mejora: pasto en la parte de abajo
        g2.setColor(new Color(34, 139, 34));
        g2.fillRect(0, getHeight() - 60, getWidth(), 60);

        //mejora: texto instructivo
        g2.setColor(Color.WHITE);
        g2.setFont(new Font("Arial", Font.ITALIC, 12));
        g2.drawString("Mové el mouse para mover el sol", 10, 20);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Dibujo Interactivo");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setLocationRelativeTo(null);
            frame.add(new panelDibujo());
            frame.pack();
            frame.setVisible(true);
        });
    }
}