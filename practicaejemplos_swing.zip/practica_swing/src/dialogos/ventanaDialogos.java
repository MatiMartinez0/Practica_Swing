package dialogos;

import javax.swing.*;
import java.awt.*;

public class ventanaDialogos extends JFrame {

    public ventanaDialogos() {
        super("Diálogos Predefinidos");
        setSize(380, 220);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        Container cp = getContentPane();
        cp.setLayout(new GridLayout(2, 2, 10, 10));
        ((JPanel) cp).setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JButton btnInfo    = new JButton("Información");
        JButton btnError   = new JButton("Error");
        JButton btnInput   = new JButton("Entrada de datos");
        JButton btnConfirm = new JButton("Confirmación");

        //información
        btnInfo.addActionListener(e ->
                JOptionPane.showMessageDialog(this,
                        "Operación completada con éxito.",
                        "Información", JOptionPane.INFORMATION_MESSAGE));

        //error
        btnError.addActionListener(e ->
                JOptionPane.showMessageDialog(this,
                        "Ocurrió un error inesperado.",
                        "Error", JOptionPane.ERROR_MESSAGE));

        //mejora: usar el valor ingresado en un mensaje posterior
        btnInput.addActionListener(e -> {
            String respuesta = JOptionPane.showInputDialog(this,
                    "¿Cuál es tu nombre?", "Tu nombre aquí");
            if (respuesta != null && !respuesta.trim().isEmpty()) {
                JOptionPane.showMessageDialog(this,
                        "Bienvenido/a, " + respuesta + "!",
                        "Saludo", JOptionPane.INFORMATION_MESSAGE);
            }
        });

        //confirmación con acción real
        btnConfirm.addActionListener(e -> {
            int respuesta = JOptionPane.showConfirmDialog(this,
                    "¿Querés cerrar la aplicación?",
                    "Confirmar salida",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.QUESTION_MESSAGE);
            if (respuesta == JOptionPane.YES_OPTION) {
                System.exit(0);
            }
        });

        cp.add(btnInfo);
        cp.add(btnError);
        cp.add(btnInput);
        cp.add(btnConfirm);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ventanaDialogos().setVisible(true));
    }
}