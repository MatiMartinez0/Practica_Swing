package componentes;

import javax.swing.*;
import java.awt.*;

public class ventanaComponentes extends JFrame {

    public ventanaComponentes() {
        super("Componentes Swing");
        setSize(450, 250);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        Container cp = getContentPane();
        cp.setLayout(new FlowLayout(FlowLayout.LEFT, 15, 20));

        JLabel etiqueta = new JLabel("Nombre:");
        etiqueta.setFont(new Font("Arial", Font.BOLD, 14));

        JTextField texto = new JTextField(20);
        //mejora: texto de ayuda al pasar el mouse
        texto.setToolTipText("Escribí tu nombre aquí");

        JButton boton = new JButton("Saludar");
        //mejora: color y cursor al boton
        boton.setBackground(new Color(70, 130, 180));
        boton.setForeground(Color.WHITE);
        boton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        boton.setFocusPainted(false);

        JCheckBox check = new JCheckBox("Recordarme");
        JRadioButton radio1 = new JRadioButton("Opción A", true);
        JRadioButton radio2 = new JRadioButton("Opción B");

        //mejora: agrupar los radio buttons correctamente
        ButtonGroup grupo = new ButtonGroup();
        grupo.add(radio1);
        grupo.add(radio2);

        cp.add(etiqueta);
        cp.add(texto);
        cp.add(boton);
        cp.add(check);
        cp.add(radio1);
        cp.add(radio2);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ventanaComponentes().setVisible(true));
    }
}