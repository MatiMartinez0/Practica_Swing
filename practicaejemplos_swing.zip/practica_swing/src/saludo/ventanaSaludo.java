package saludo;

import javax.swing.*;
import java.awt.*;

public class ventanaSaludo extends JFrame {

    private JTextField txtNombre;
    private JTextArea areaHistorial;

    public ventanaSaludo() {
        super("Saludo Interactivo");
        setSize(420, 350);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        //panel superior: entrada
        JPanel panelEntrada = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        panelEntrada.add(new JLabel("Nombre:"));
        txtNombre = new JTextField(18);
        JButton btnSaludar = new JButton("Saludar");
        btnSaludar.setCursor(new Cursor(Cursor.HAND_CURSOR));
        panelEntrada.add(txtNombre);
        panelEntrada.add(btnSaludar);

        //mejora: historial de saludos
        areaHistorial = new JTextArea(10, 30);
        areaHistorial.setEditable(false);
        areaHistorial.setFont(new Font("Monospaced", Font.PLAIN, 13));
        areaHistorial.setBorder(BorderFactory.createTitledBorder("Historial de saludos"));
        JScrollPane scroll = new JScrollPane(areaHistorial);

        //botón para limpiar
        JButton btnLimpiar = new JButton("Limpiar historial");
        btnLimpiar.addActionListener(e -> areaHistorial.setText(""));

        //acción principal
        btnSaludar.addActionListener(e -> saludar());
        //mejora: también funciona presionando Enter
        txtNombre.addActionListener(e -> saludar());

        Container cp = getContentPane();
        cp.setLayout(new BorderLayout(5, 5));
        cp.add(panelEntrada, BorderLayout.NORTH);
        cp.add(scroll, BorderLayout.CENTER);
        cp.add(btnLimpiar, BorderLayout.SOUTH);
    }

    private void saludar() {
        String nombre = txtNombre.getText().trim();
        if (nombre.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Ingresá un nombre primero.",
                    "Atención", JOptionPane.WARNING_MESSAGE);
            return;
        }
        areaHistorial.append("→ ¡Hola, " + nombre + "!\n");
        txtNombre.setText("");
        txtNombre.requestFocus();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ventanaSaludo().setVisible(true));
    }
}