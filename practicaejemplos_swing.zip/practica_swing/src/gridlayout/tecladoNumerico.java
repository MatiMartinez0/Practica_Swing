package gridlayout;

import javax.swing.*;
import java.awt.*;

public class tecladoNumerico extends JFrame {

    private JTextField display;

    public tecladoNumerico() {
        super("Teclado Numérico");
        setSize(280, 380);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        Container cp = getContentPane();
        cp.setLayout(new BorderLayout(5, 5));

        //mejora: display en la parte superior
        display = new JTextField("0");
        display.setHorizontalAlignment(JTextField.RIGHT);
        display.setFont(new Font("Monospaced", Font.BOLD, 24));
        display.setEditable(false);
        display.setBackground(Color.BLACK);
        display.setForeground(Color.GREEN);
        cp.add(display, BorderLayout.NORTH);

        //panel de botones con gridlayout
        JPanel panelBotones = new JPanel(new GridLayout(4, 3, 5, 5));
        panelBotones.setBorder(BorderFactory.createEmptyBorder(5, 10, 10, 10));

        String[] etiquetas = {"1","2","3","4","5","6","7","8","9","+","0","-"};

        for (String etiqueta : etiquetas) {
            JButton btn = new JButton(etiqueta);
            btn.setFont(new Font("Arial", Font.BOLD, 18));
            btn.setBackground(new Color(60, 60, 60));
            btn.setForeground(Color.WHITE);
            btn.setFocusPainted(false);
            btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
            //mejora: al pulsar un numero se muestra en el display
            btn.addActionListener(e -> {
                String actual = display.getText();
                if (actual.equals("0")) {
                    display.setText(e.getActionCommand());
                } else {
                    display.setText(actual + e.getActionCommand());
                }
            });
            panelBotones.add(btn);
        }

        //mejora: boton de borrar
        JButton btnBorrar = new JButton("C");
        btnBorrar.setFont(new Font("Arial", Font.BOLD, 14));
        btnBorrar.setBackground(new Color(180, 50, 50));
        btnBorrar.setForeground(Color.WHITE);
        btnBorrar.setFocusPainted(false);
        btnBorrar.addActionListener(e -> display.setText("0"));
        cp.add(btnBorrar, BorderLayout.SOUTH);

        cp.add(panelBotones, BorderLayout.CENTER);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new tecladoNumerico().setVisible(true));
    }
}