package eventos;

import javax.swing.*;
import java.awt.*;

public class botonconEvento extends JFrame {

    private int contadorClicks = 0;

    public botonconEvento() {
        super("Eventos de Botón");
        setSize(300, 180);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        Container cp = getContentPane();
        cp.setLayout(new FlowLayout(FlowLayout.CENTER, 15, 30));

        JLabel lblContador = new JLabel("Clics: 0");
        lblContador.setFont(new Font("Arial", Font.BOLD, 16));

        JButton boton = new JButton("¡Clickeame!");
        boton.setFont(new Font("Arial", Font.PLAIN, 14));
        boton.setCursor(new Cursor(Cursor.HAND_CURSOR));

        //mejora: el boton cambia de color y muestra el contador
        boton.addActionListener(e -> {
            contadorClicks++;
            lblContador.setText("Clicks: " + contadorClicks);
            //el botón cambia de color despues de 5 clicks
            if (contadorClicks >= 5) {
                boton.setBackground(Color.RED);
                boton.setForeground(Color.WHITE);
                boton.setText("¡BASTAA!");
            }
        });

        cp.add(boton);
        cp.add(lblContador);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new botonconEvento().setVisible(true));
    }
}