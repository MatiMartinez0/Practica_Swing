package ventana;

import javax.swing.*;
import java.awt.*;

public class ventanaBasica extends JFrame {

    public ventanaBasica() {
        super("Hola");
        setSize(500, 350);
        setMinimumSize(new Dimension(300, 200));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //mejora: centrar la ventana en la pantalla
        setLocationRelativeTo(null);
        //mejora: color de fondo
        getContentPane().setBackground(new Color(10, 131, 163));
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            ventanaBasica v = new ventanaBasica();
            v.setVisible(true);
        });
    }
}